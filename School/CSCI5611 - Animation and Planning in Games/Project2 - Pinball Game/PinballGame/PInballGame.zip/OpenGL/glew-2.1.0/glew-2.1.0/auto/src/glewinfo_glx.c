}

#elif !defined(GLEW_EGL) && !defined(GLEW_OSMESA) /* _UNIX */

static void glxewInfo ()
{
