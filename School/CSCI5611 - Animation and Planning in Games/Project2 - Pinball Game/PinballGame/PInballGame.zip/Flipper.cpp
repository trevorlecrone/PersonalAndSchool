#include "Flipper.h"

Vec2 Flipper::LinearVelocityAtPoint(Vec2 point) { return Vec2(); }